HAL/LED/LED.o HAL/LED/LED.o: ../HAL/LED/LED.c \
  ../HAL/LED/../../LIB/BIT_MATH.h ../HAL/LED/../../LIB/STD_TYPES.h \
  ../HAL/LED/../../MCAL/DIO/DIO.h ../HAL/LED/LED.h

../HAL/LED/../../LIB/BIT_MATH.h:

../HAL/LED/../../LIB/STD_TYPES.h:

../HAL/LED/../../MCAL/DIO/DIO.h:

../HAL/LED/LED.h:
