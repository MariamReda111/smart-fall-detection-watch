MCAL/ADC/ADC.o MCAL/ADC/ADC.o: ../MCAL/ADC/ADC.c \
  ../MCAL/ADC/../../LIB/BIT_MATH.h ../MCAL/ADC/../../LIB/STD_types.h \
  ../MCAL/ADC/ADC.h

../MCAL/ADC/../../LIB/BIT_MATH.h:

../MCAL/ADC/../../LIB/STD_types.h:

../MCAL/ADC/ADC.h:
